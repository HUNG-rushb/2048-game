var React = require('react')

function GridCell() {
  return <div className="grid-cell"></div>;
}

module.exports = GridCell;
